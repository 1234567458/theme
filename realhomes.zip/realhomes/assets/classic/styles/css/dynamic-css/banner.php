<?php
/**
 * Containing dynamic css banner style options
 *
 * @since      4.4.0
 * @package    realhomes
 * @subpackage classic
 */

$banner_keys = array(
	'theme_banner_text_color',
	'theme_banner_sub_text_color',
	'theme_banner_title_bg_color',
	'theme_banner_sub_title_bg_color'
);

$banner_options = realhomes_get_options( $banner_keys );

$banner_css = array(
	'elements' => '.page-head .page-title span',
	'property' => 'color',
	'value'    => $banner_options[ 'theme_banner_text_color' ]
);

$banner_css = array(
	'elements' => '.page-head .page-title span',
	'property' => 'background-color',
	'value'    => $banner_options[ 'theme_banner_title_bg_color' ]
);

$banner_css = array(
	'elements' => '.page-head p',
	'property' => 'color',
	'value'    => $banner_options[ 'theme_banner_sub_text_color' ]
);

$banner_css = array(
	'elements' => '.page-head p',
	'property' => 'background-color',
	'value'    => $banner_options[ 'theme_banner_sub_title_bg_color' ]
);

return $banner_css;
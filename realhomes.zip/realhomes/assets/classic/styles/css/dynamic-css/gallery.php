<?php
/**
 * Containing dynamic css gallery style options
 *
 * @since      4.4.0
 * @package    realhomes
 * @subpackage classic
 */

$gallery_keys = array(
	'inspiry_gallery_hover_color'
);

$gallery_options = realhomes_get_options( $gallery_keys );

$gallery_css = array(
	'elements' => '.gallery-item .media_container',
	'property' => 'background-color',
	'value'    => inspiry_hex_to_rgba( $gallery_options['inspiry_gallery_hover_color'], 0.9 ),
);

return $gallery_css;
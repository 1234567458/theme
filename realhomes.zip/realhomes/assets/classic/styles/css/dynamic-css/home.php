<?php
/**
 * Containing dynamic css home style options
 *
 * @since      4.4.0
 * @package    realhomes
 * @subpackage classic
 */

$home_keys = array(
	'inspiry_features_text_color',
	'inspiry_features_background_color'
);

$home_options = realhomes_get_options( $home_keys );

$home_css = array(
	'elements' => '.home-features-section .home-features-bg',
	'property' => 'background-color',
	'value'    => $home_options[ 'inspiry_features_background_color' ]
);

$home_css = array(
	'elements' => '
		.home-features-section .headings h2,
		.home-features-section .headings p,
		.home-features-section .features-wrapper .features-single .feature-content h4,
		.home-features-section .features-wrapper .features-single .feature-content p
	',
	'property' => 'color',
	'value'    => $home_options[ 'inspiry_features_text_color' ]
);

return $home_css;
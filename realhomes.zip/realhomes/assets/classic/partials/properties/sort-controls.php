<?php
/**
 * Sort Controls
 *
 * Properties sort controls.
 *
 * @package    realhomes
 * @subpackage classic
 */

realhomes_generate_sort_control_option( array(
    'container_classes' => 'sort-controls'
) );
?>
<div class="option-bar rh-search-field large">
    <label for="select-guests"><?php echo esc_html__( 'Guests', RH_TEXT_DOMAIN ); ?></label>
    <span class="selectwrap">
		<select name="guests" id="select-guests" class="inspiry_select_picker_trigger show-tick"><?php inspiry_min_guests(); ?></select>
	</span>
</div>
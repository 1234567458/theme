<?php
/**
 * Blog Loop File
 *
 * Loop file of blog.
 *
 * @package    realhomes
 * @subpackage classic
 */

if ( have_posts() ) :
	while ( have_posts() ) :
		the_post();
		get_template_part( 'assets/classic/partials/blog/article' );
	endwhile;

	the_posts_pagination(array(
	        'mid_size' => 2,
        'prev_text' => esc_html__('Prev', RH_TEXT_DOMAIN ),
        'next_text' => esc_html__('Next', RH_TEXT_DOMAIN ),
    ));
else :
	?><p class="nothing-found"><?php esc_html_e( 'No Posts Found!', RH_TEXT_DOMAIN ); ?></p><?php
endif;

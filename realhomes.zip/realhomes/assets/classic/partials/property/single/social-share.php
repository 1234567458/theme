<?php if ( 'true' === get_option( 'theme_display_social_share', 'true' ) ) : ?>
    <div class="share-networks clearfix">
        <span class="share-label"><?php esc_html_e( 'Share this', RH_TEXT_DOMAIN ); ?></span>
        <span><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><i class="fab fa-facebook fa-lg"></i><?php esc_html_e( 'Facebook', RH_TEXT_DOMAIN ); ?></a></span>
        <span><a target="_blank" href="https://twitter.com/share?url=<?php the_permalink(); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16"><path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865z"></path></svg><?php esc_html_e( 'Twitter', RH_TEXT_DOMAIN ); ?></a></span>
        <span><a target="_blank" href="https://api.whatsapp.com/send?text=<?php echo get_the_title() . '&nbsp;' . get_the_permalink(); ?>"><i class="fab fa-whatsapp fa-lg"></i><?php esc_html_e( 'WhatsApp', RH_TEXT_DOMAIN ); ?></a></span>
        <span><a href="mailto:?subject=<?php echo esc_html( get_the_title() ); ?>&body=<?php echo urlencode( get_the_permalink() ); ?>" target="_blank"><i class="fas fa-envelope fa-lg"></i><?php esc_html_e( 'Email', RH_TEXT_DOMAIN ); ?></a></span>
		<?php if ( 'true' === get_option( 'realhomes_line_social_share', 'false' ) ) : ?>
            <span><a target="_blank" href="https://social-plugins.line.me/lineit/share?url=<?php the_permalink(); ?>"><i class="fab fa-line fa-lg"></i><?php esc_html_e( 'Line', RH_TEXT_DOMAIN ); ?></a></span>
		<?php endif; ?>
    </div>
<?php endif; ?>
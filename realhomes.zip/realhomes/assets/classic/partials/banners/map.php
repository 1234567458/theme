
<!-- Markup to Handle Map ( Both Google and Open Street ) -->
<div id="map-head">
	<div id="listing-map"></div>
</div>

<?php
/**
 * Property location surroundings and outdoor features of single property.
 *
 * @package    realhomes
 * @subpackage modern
 * @since 4.4.2
 */
if ( inspiry_is_rvr_enabled() && ( 'true' === get_option( 'realhomes_rvr_surroundings', 'true' ) || 'true' === get_option( 'realhomes_rvr_outdoor_features', 'true' ) ) ) {
	?>
    <div class="features-content-wrapper single-property-section <?php realhomes_printable_section( 'rvr/location-surroundings' ); ?>">
        <div class="container">
			<?php get_template_part( 'assets/modern/partials/property/single/rvr/location-surroundings' ); ?>
        </div>
    </div>
	<?php
}
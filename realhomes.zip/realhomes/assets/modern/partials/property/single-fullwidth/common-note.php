<?php if ( 'true' === get_option( 'theme_display_common_note' ) ) : ?>
    <div class="common-note-content-wrapper single-property-section">
        <div class="container">
			<?php get_template_part( 'assets/modern/partials/property/single/common-note' ); ?>
        </div>
    </div>
<?php endif; ?>
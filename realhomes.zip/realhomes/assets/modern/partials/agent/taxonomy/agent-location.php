<?php
/**
 * Taxonomy: Agent Location
 *
 * @since      4.0.0
 * @package    realhomes
 * @subpackage modern
 */

get_template_part( 'assets/modern/partials/agent/taxonomy/agents' );

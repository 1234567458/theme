<?php
/**
 * Blog post meta
 *
 * @package    realhomes
 * @subpackage modern
 */
?>
<div class="entry-meta blog-post-entry-meta">
	<?php
	printf(
		esc_html_x( 'By %s', 'author byline', RH_TEXT_DOMAIN ),
		sprintf(
			'<p class="vcard fn">%1$s</p>',
			esc_html( get_the_author_meta( 'display_name' ) )
		)
	);
	echo ' ';
	esc_html_e( 'Posted in', RH_TEXT_DOMAIN );
	echo ' ';
	the_category( ', ' );
	echo ' ';
	esc_html_e( 'On ', RH_TEXT_DOMAIN );
	echo ' ';
	?>
	<time class="entry-date published" datetime="<?php the_time( 'c' ); ?>"><?php the_time( get_option('date_format', 'M d, Y' ) ); ?></time>
</div>
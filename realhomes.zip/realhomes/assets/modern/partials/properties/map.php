
<!-- properties map -->
<div id="map-head" class="<?php echo realhomes_is_dual_price_enabled() ? 'dual-price' : ''; ?>">
	<div id="listing-map"></div>
</div>


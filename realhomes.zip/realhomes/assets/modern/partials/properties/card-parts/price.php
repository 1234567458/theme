<?php
$property_id = get_the_ID();
?>
<div class="rh_theme_card__priceLabel_sty">
    <span class="rh_theme_card__status_sty">
        <?php
        if ( function_exists( 'ere_get_property_statuses' ) ) {
	        echo esc_html( ere_get_property_statuses( $property_id ) );
        }
        ?>
    </span>
    <p class="rh_theme_card__price_sty <?php echo realhomes_is_dual_price_enabled( $property_id ) ? 'dual-price' : ''; ?>">
		<?php
		if ( function_exists( 'ere_property_price' ) ) {
			ere_property_price();
		}
		?>
    </p>
</div>
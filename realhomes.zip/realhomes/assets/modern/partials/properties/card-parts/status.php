<div class="rh_soi_prop_status_sty">
<?php display_property_status_html(get_the_ID()); ?>
</div>

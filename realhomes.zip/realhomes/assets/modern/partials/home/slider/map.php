<?php
/**
 * Map based slider area form homepage.
 *
 * @package    realhomes
 * @subpackage modern
 */

?>

<section class="rh_map">
	<?php get_template_part( 'assets/modern/partials/properties/map' ); ?>
</section>
<!-- /.rh_map -->

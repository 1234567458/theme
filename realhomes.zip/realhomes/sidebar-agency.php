<?php
/**
 * Sidebar: Agency
 *
 * @since 3.5.0
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/sidebar/agency' );
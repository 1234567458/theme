<?php
/**
 * Single Property
 *
 * @package realhomes
 */

if ( ! empty( $_GET['print_view'] ) && '1' === $_GET['print_view'] ) {
	get_template_part( 'single-property-print' );
} else {
	get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/property/single' );
}